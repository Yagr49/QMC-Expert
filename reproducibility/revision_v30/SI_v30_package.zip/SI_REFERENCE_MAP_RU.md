# Ссылки статьи на обновлённый SI

Статья: `2026_10_14_Paper_2_edited-v30_SI_aligned.docx`. Основной текст и рисунки сохранены; изменены только ссылки на SI.

Текст и новые графики: Futura Medium. Шесть исходных растровых рисунков сохраняют оригинальное содержимое и шрифт внутри изображения.

| Было в SI v27 | Теперь | Содержание |
|---|---|---|
| Table S1 | Table S1 | Canonical-molecule overlap in the recovered historical archive, before strict follow-up exclusions |
| Table S45 | Table S2 | Original v5 Table 1, preserved numerical cells |
| Table S46 | Table S3 | Original v5 Table 2, preserved numerical cells |
| Table S39 | Table S5 | Task-code substitution controls with human compact seed 0 |
| Table S40 | Table S6 | Five-fold row-CV reconstruction: mean ± fold SD (ddof=0) |
| Table S35 | Table S7 | Reconstructed original-108 holdout endpoint metrics |
| Table S41 | Table S8 | Complete compact-arm results: mean ± sample SD across source runs (ddof=1) |
| Table S36 | Table S9 | Every compact-control and archived-representation configuration: seed-mean RMSE |
| Table S37 | Table S10 | Complete paired compact-control ΔRMSE intervals |
| Table S28 | Table S11 | Complete direct-target pooled results: mean ± sample SD over three seed-specific scores, rather than metrics of averaged predictions |
| Table S29 | Table S12 | Complete direct-target endpoint scores |
| Table S38 | Table S13 | Archived-v5-feature modern decoder endpoint results |
| Table S42 | Table S14 | Complete grouped fold variability for archived-feature and modern-decoder procedures |
| Table S23 | Table S15 | Earlier fixed-model extension including Chemprop and all graph/tabular reference pipelines |
| Table S47 | Table S16 | Q-HERO405 classification |
| Table S48 | Table S17 | Paired Q-HERO scaffold contrasts: 2,000 paired seed/scaffold bootstrap draws over fixed OOF predictions and 29 scaffolds |
| Table S19 | Table S18 | All 105 original full-salt identities and original worksheet-row identifiers |
| Table S20 | Table S19 | All 17 OOD compounds and supplied MIC/MBC values in mg/L |
| Table S49 | Table S20 | OOD route scores on 67 exact endpoints |
| Table S22 | Table S21 | Right-censored endpoint minimum-error sensitivity under its original stated protocol |
| Table S33 | Table S22 | Per-run human-guided censored-endpoint sensitivity from independently replayed predictions |
| Table S43 | Table S23 | Recovered five-fold linear representation-probe results |
| Table S50 | Table S24 | Complete scaffold-clustered label and weight intervention contrasts plotted in Figure S11 |
| Table S26 | Table S27 | Independent reproduction outcomes for the original v14 workflows |
| Table S34 | Table S28 | Original v5 hypotheses and corresponding follow-ups |
| Table S44 | Table S29 | Relationship of added computations to the author workflow |

Figure S33 → S13 (исходный few-shot); S34 → S14 (исходная схема); S35 → S11 (контроли). Сведения text-embedding-3-small: раздел S2.

Ссылка химической части на старую Table S1 исправлена на Table S26: пока это явно обозначенное место для исходной таблицы оптимизации. Scheme S1–S2 также оставлены для соавторов.

Все прежние вычисления сохранены отдельно в SI_v27_full_archive.docx. Его номера не используются в обновлённой статье.
