"""Build a manuscript-aligned SI from preserved results; no training or metric refits."""
from pathlib import Path
from copy import deepcopy
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib, importlib.util, json, os, re, shutil
os.environ.setdefault('MPLCONFIGDIR', '/private/tmp/coma_v30_mpl')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from lxml import etree as E

ROOT=Path(__file__).resolve().parent
REPRO=ROOT.parent
COMA=REPRO.parent
OLD=REPRO/'revision_v27/Supplementary_Information_v27.docx'
MAIN=COMA/'2026_10_14_Paper_2_edited-v29_explainability_figure.docx'
OUTMAIN=COMA/'2026_10_14_Paper_2_edited-v30_SI_aligned.docx'
spec=importlib.util.spec_from_file_location('theme', REPRO/'revision_v27/theme_v27.py')
T=importlib.util.module_from_spec(spec);spec.loader.exec_module(T)
T.theme(9)
FIG=ROOT/'figures';DATA=ROOT/'data'
FIG.mkdir(parents=True,exist_ok=True);DATA.mkdir(exist_ok=True)
INPUTS={}; TABLE_MAP={}; COPIED_TABLES=[]; FIGURES=[]

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(path):
    p=Path(path);INPUTS[str(p.relative_to(COMA))]=sha(p)
    return pd.read_csv(p)
def saved(fig,stem):
    T.save(fig,FIG,stem)
    FIGURES.append(stem)
def plots():
    row=read(REPRO/'revision_v19/rowcv_results/summary.csv')
    fig,axes=plt.subplots(1,2,figsize=(7.1,2.9),sharey=True)
    tasks=['Sa_MIC','Sa_MBC','Ec_MIC','Ec_MBC'];labels=['Sa MIC','Sa MBC','Ec MIC','Ec MBC']
    for ax,rep,title in zip(axes,['v5_raw','v5_human'],['Raw MolFormer','Human-guided features']):
        for j,(code,label,col) in enumerate([('categorical_org_met','Species + endpoint',T.BLUE),('categorical_task_id','Task ID',T.PEACH),('text','Text task code',T.MINT)]):
            a=row[row.representation.eq(rep)&row.encoding.eq(code)].set_index('task').loc[tasks]
            ax.errorbar(np.arange(4)+(j-1)*.18,a.R2_mean,yerr=a.R2_sd,fmt='o',ms=4,color=col['edge'],capsize=2,lw=.9,label=label)
        ax.set_title(title);ax.set_xticks(range(4));ax.set_xticklabels(labels,rotation=20,ha='right');T.despine(ax)
        ax.set_ylim(-.13,1.05);ax.axhline(0,color=T.RULE,lw=.6)
    axes[0].set_ylabel('Endpoint R²');fig.legend(*axes[0].get_legend_handles_labels(),loc='lower center',ncol=3,fontsize=7.3)
    fig.tight_layout(rect=(0,.12,1,1));saved(fig,'figureS5_row_cv')
    seeds=read(REPRO/'revision_v19/analysis/seed_summary.csv')
    raw_summary=read(REPRO/'revision_v18/analysis/summary.csv')
    arms=[('matched_raw','Raw',T.GREY),('human','Human',T.MINT),('mic_continuous','Quantitative',T.LAV),('human_shuffled','Shuffled',T.PEACH)]
    fig,axes=plt.subplots(1,3,figsize=(7.1,2.9),sharey=True)
    for ax,schema,title in zip(axes,['cation','scaffold','full-QAC105'],['Cation holdout','Scaffold holdout','OOD-17']):
        for i,(arm,label,col) in enumerate(arms):
            if arm=='matched_raw':
                a=raw_summary[raw_summary.arm.eq(arm)&raw_summary.encoding.eq('categorical')&raw_summary.task.eq('pooled')&raw_summary.schema.eq(schema)].iloc[0]
                mean,sd=a.RMSE,None
            else:
                a=seeds[seeds.arm.eq(arm)&seeds.encoding.eq('categorical')&seeds.task.eq('pooled')&seeds.schema.eq(schema)].iloc[0]
                mean,sd=a.RMSE_seed_mean,a.RMSE_seed_sd if a.n_seeds>1 else None
            ax.errorbar(i,mean,yerr=sd,fmt='o',ms=5,color=col['edge'],capsize=3,lw=1)
        ax.set_title(title);ax.set_xticks(range(4));ax.set_xticklabels([a[1] for a in arms],rotation=35,ha='right');T.despine(ax)
    axes[0].set_ylabel(r'Pooled RMSE, log$_2$(mg/L)');fig.tight_layout();saved(fig,'figureS6_compact_seed_variability')
    modern=read(REPRO/'revision_v18/analysis/modern_metrics.csv')
    fig,axes=plt.subplots(1,3,figsize=(7.1,3),sharey=True)
    models=['tabfm','tabpfn','autogluon']
    for ax,schema,title in zip(axes,['cation','scaffold','full-QAC105'],['Cation holdout','Scaffold holdout','OOD-17']):
        for i,rep in enumerate(['v5_raw','v5_human']):
            a=modern[modern.representation.eq(rep)&modern.task.eq('pooled')&modern.schema.eq(schema)].set_index('model').loc[models]
            ax.plot(np.arange(3)+(i-.5)*.18,a.RMSE,'o',ms=5,color=[T.GREY,T.MINT][i]['edge'],label=['Raw','Human'][i])
        ax.set_title(title);ax.set_xticks(range(3));ax.set_xticklabels(['TabFM','TabPFN','AutoGluon'],rotation=25,ha='right');T.despine(ax)
    axes[0].set_ylabel(r'Pooled RMSE, log$_2$(mg/L)');fig.legend(*axes[0].get_legend_handles_labels(),loc='lower center',ncol=2)
    fig.tight_layout(rect=(0,.1,1,1));saved(fig,'figureS7_modern_decoders')
    q=read(REPRO/'qhero_author_comparison_20261014/results/summary.csv')
    qa=[('RF_35_descriptors','RF35',T.BLUE),('CB_raw_MolFormer','Raw',T.GREY),('CB_human','Human',T.MINT),('CB_quantitative','Quantitative',T.LAV),('CB_shuffled_human','Shuffled',T.PEACH)]
    fig,axes=plt.subplots(1,2,figsize=(7.1,3.1),sharey=True)
    for ax,protocol,title in zip(axes,['random_heldout20','scaffold_CV_pooled'],['Random test','Scaffold holdout']):
        a=q[q.protocol.eq(protocol)].set_index('model')
        for i,(model,label,col) in enumerate(qa):
            ax.errorbar(i,a.loc[model,'AUPRC'],yerr=a.loc[model,'AUPRC_SD'] if a.loc[model,'repeats']>1 else None,fmt='o',color=col['edge'],ms=5,lw=1,capsize=3)
        ax.axhline(72/81 if protocol=='random_heldout20' else 360/405,color=T.RULE,lw=.8,ls='--')
        ax.set_xticks(range(5));ax.set_xticklabels([a[1] for a in qa],rotation=25,ha='right');ax.set_title(title);T.despine(ax)
    axes[0].set_ylabel('Average precision');axes[0].set_ylim(.85,1.005)
    fig.tight_layout();saved(fig,'figureS8_qhero_average_precision')
    p=read(REPRO/'revision_v18/analysis/predictions.csv')
    o=p[p.cohort.eq('OOD17')&p.schema.eq('full-QAC105')&p.encoding.eq('categorical')&p.qualifier.eq('=')]
    fig,axes=plt.subplots(2,2,figsize=(6.5,5.7),sharex=True,sharey=True)
    for ax,task,label in zip(axes.flat,tasks,labels):
        for arm,legend,col in [('human','Human',T.MINT),('mic_continuous','Quantitative',T.LAV)]:
            a=o[o.arm.eq(arm)&o.task.eq(task)].groupby('compound_id').agg(y=('y','first'),pred=('prediction','mean'),n=('seed','nunique'))
            assert a.n.eq(5).all() and len(a)==(16 if task=='Ec_MBC' else 17)
            ax.scatter(a.y,a.pred,s=21,alpha=.8,c=col['fill'],edgecolor=col['edge'],lw=.5,label=legend)
        ax.plot([-2,10],[-2,10],color=T.RULE,ls='--',lw=.6);ax.set_xlim(-1,10);ax.set_ylim(-1,10);ax.set_title(label);T.despine(ax,grid='both')
    for ax in axes[1]:ax.set_xlabel(r'Measured log$_2$(mg/L)')
    for ax in axes[:,0]:ax.set_ylabel(r'Predicted log$_2$(mg/L)')
    fig.legend(*axes[0,0].get_legend_handles_labels(),loc='lower center',ncol=2)
    fig.tight_layout(rect=(0,.055,1,1));saved(fig,'figureS9_ood_endpoint_parity')
    fig,axes=plt.subplots(1,3,figsize=(7.1,2.8))
    geometry=[.933243,.945559]; probes=[.890919,.844077];sds=[.036773,.060385]
    shap=[2.9301,.6359,.7605]
    axes[0].bar(range(2),geometry,color=[T.BLUE['fill'],T.LAV['fill']],width=.65)
    axes[0].set_xticks(range(2));axes[0].set_xticklabels(['Reference','OOD']);axes[0].set_ylim(0,1);axes[0].set_ylabel('Linear CKA');axes[0].set_title('Shared geometry')
    axes[1].errorbar(range(2),probes,yerr=sds,fmt='o',ms=5,capsize=3,color=T.MINT['edge']);axes[1].set_xticks(range(2));axes[1].set_xticklabels(['Raw › human','Human › raw'],rotation=20,ha='right');axes[1].set_ylim(0,1);axes[1].set_ylabel('Probe R²');axes[1].set_title('Linear recoverability')
    axes[2].bar(range(3),shap,color=[T.GREY['fill'],T.MINT['fill'],T.PEACH['fill']],width=.65);axes[2].set_xticks(range(3));axes[2].set_xticklabels(['Raw','Human','Task']);axes[2].set_ylabel('Sum of mean |SHAP|');axes[2].set_title('Decoder attribution')
    for ax in axes:T.despine(ax)
    fig.tight_layout();saved(fig,'figureS10_geometry_and_attribution')
    pd.DataFrame({'analysis':['CKA reference','CKA OOD','Probe raw to human','Probe human to raw','SHAP raw','SHAP human','SHAP task'],'value':geometry+probes+shap,'SD':[None,None]+sds+[None]*3}).to_csv(DATA/'geometry_and_attribution.csv',index=False)
    INPUTS['analysis/cka_probing.csv']=sha(COMA/'analysis/cka_probing.csv')
    INPUTS['reproducibility/notebook_recovery_20261012/notebooks/2026-05-25_causal_final.ipynb']=sha(REPRO/'notebook_recovery_20261012/notebooks/2026-05-25_causal_final.ipynb')
    controls=read(REPRO/'revision_v26/interpretation_contrasts.csv')
    fig,axes=plt.subplots(1,2,figsize=(7.1,3.65),sharey=True)
    fig.subplots_adjust(left=.23,right=.985,bottom=.24,top=.86,wspace=.18)
    keys=[(scheme,contrast) for scheme in ['cation','scaffold','full-QAC105'] for contrast in ['Human − shuffled','Reset weights − intact']]
    labels=[f'{label} · {kind}' for label in ['Cation','Scaffold','OOD-17'] for kind in ['Labels','Weights']]
    for ax,experiment,title in zip(axes,['compact','partial'],['Compact encoders','Partial backbone']):
        for i,(scheme,contrast) in enumerate(keys):
            a=controls[controls.experiment.eq(experiment)&controls.scheme.eq(scheme)&controls.contrast.eq(contrast)].iloc[0]
            col=T.MINT if i%2==0 else T.LAV
            ax.plot([a.low,a.high],[5-i,5-i],color=col['edge'],lw=1.4)
            ax.plot(a.delta,5-i,'o',ms=5,mec=col['edge'],mfc='white' if a.low<=0<=a.high else col['fill'],mew=1)
        ax.set_title(title);ax.axvline(0,color=T.RULE,ls='--',lw=.7);ax.set_xlim(-.68,.68);ax.set_ylim(-.5,5.5)
        ax.set_yticks(range(6));ax.set_yticklabels(labels[::-1]);ax.set_xlabel(r'ΔRMSE, log$_2$(mg/L)');T.despine(ax,grid='x')
    from matplotlib.lines import Line2D
    fig.legend(handles=[Line2D([],[],marker='o',color=T.MINT['edge'],label='Human − shuffled'),Line2D([],[],marker='o',color=T.LAV['edge'],label='Reset weights − intact'),Line2D([],[],marker='o',ls='',mec=T.RULE,mfc='white',label='Interval includes zero')],loc='lower center',ncol=3,fontsize=7)
    saved(fig,'figureS11_figure9_interpretation_controls_futura')
    for num,stem in [(12,'figure10_supervision_contrasts_futura')]:
        for ext in ['png','pdf','svg']:
            p=REPRO/'revision_v27/figures'/f'{stem}.{ext}'
            dest=FIG/f'figureS{num}_{stem}.{ext}';shutil.copy2(p,dest);INPUTS[str(p.relative_to(COMA))]=sha(p)
        FIGURES.append(f'figureS{num}_{stem}')

def txt(n):return ''.join(t.text or '' for t in n.iter(qn('w:t')))
doc=Document(OLD);original=list(doc._element.body)
TABLES={};LEGACY={}
for i,n in enumerate(original):
    m=re.match(r'Table S(\d+)\.',txt(n))
    if m:
        table=next(c for c in original[i+1:] if c.tag==qn('w:tbl'))
        TABLES[int(m[1])]=(txt(n),deepcopy(table))
    m=re.match(r'Figure S(\d+)\.',txt(n))
    if m and int(m[1]) in [1,2,3,4,33,34]:
        LEGACY[int(m[1])]=(deepcopy(original[i-1]),txt(n))
for n in list(doc._element.body):
    if n.tag!=qn('w:sectPr'):doc._element.body.remove(n)
section=doc.sections[0];section.page_width=Inches(8.27);section.page_height=Inches(11.69)
section.top_margin=section.bottom_margin=Inches(.7);section.left_margin=section.right_margin=Inches(.65)
for style in doc.styles:
    if hasattr(style,'font'):
        style.font.name='Futura';style.font.color.rgb=RGBColor.from_string('1B1C1F')
doc.styles['Normal'].font.size=Pt(10)
doc.styles['Normal'].paragraph_format.space_after=Pt(6)
doc.styles['Normal'].paragraph_format.line_spacing=1.12
for name,size in [('Title',18),('Heading 1',14),('Heading 2',11),('Caption',9)]:
    doc.styles[name].font.name='Futura';doc.styles[name].font.size=Pt(size)
    doc.styles[name].paragraph_format.keep_with_next=True

def para(s,style=None):return doc.add_paragraph(s,style)
def heading(s):return doc.add_heading(s,level=1)
def insert(n):doc._element.body.insert(len(doc._element.body)-1,deepcopy(n))
def table(old,caption=None):
    number=len(COPIED_TABLES)+1
    TABLE_MAP[old]=number
    cap,n=TABLES[old]
    cap=caption or cap.split('. ',1)[1]
    para(f'Table S{number}. {cap}','Caption');insert(n)
    COPIED_TABLES.append({'number':number,'old':old,'caption':cap})
    return number
def newtable(caption,headers,rows,key):
    number=len(COPIED_TABLES)+1
    para(f'Table S{number}. {caption}','Caption')
    tab=doc.add_table(rows=1,cols=len(headers));tab.style='Table Grid'
    for c,s in zip(tab.rows[0].cells,headers):c.text=str(s)
    for r in rows:
        for c,s in zip(tab.add_row().cells,r):c.text=str(s)
    COPIED_TABLES.append({'number':number,'old':key,'caption':caption})
    return number
def figure(num,stem,caption):
    p=doc.add_paragraph();p.paragraph_format.keep_with_next=True
    p.add_run().add_picture(str(FIG/(stem+'.png')),width=Inches(6.9))
    para(f'Figure S{num}. {caption}','Caption')
def legacy(old,new,caption):
    image,_=LEGACY[old];insert(image)
    para(f'Figure S{new}. {caption}','Caption')

def build():
    title=Document(MAIN).paragraphs[0].text
    para('Supporting Information','Title');para(title)
    para('Manuscript-aligned computational methods, complete results and chemical records. Revision 30, 14 October 2026.')
    para('All tables are editable. Current plots use Futura Medium and the shared pastel palette. Original author figures are retained as labelled archival raster sources; their embedded typography and numerical values are preserved.')
    para('Contents','Heading 1')
    chapters=['S1. Expert annotation and molecular representations','S2. Reference v5 results and task encoding','S3. Validation, matched compact encoders and uncertainty','S4. Backbone adaptation and prediction routes','S5. Molecular and tabular decoder comparisons','S6. External Q-HERO classification','S7. The 105-QAC register and structural OOD evaluation','S8. Geometry, attribution and intervention controls','S9. Chemistry and microbiological methods','S10. Reproduction, artifact provenance and references','S11. Archived OOD and information-flow illustrations']
    for s in chapters:para(s)
    heading(chapters[0])
    para('The recovered archive contains 1,103 final Good/Bad calls: 859 Bad and 244 Good. Standardisation gives 1,066 canonical full salts. The earlier collection-stage count of 1,500 is not treated as a verified training count. Historical target overlap and strict source exclusions are different protocols; Table S1 describes the recovered archive before exclusions.')
    para('[COAUTHORS: complete the collection dates, annotator identities and expertise, information shown, access to quantitative values, blinding, vote aggregation, uncertain-case handling, exclusions and agreement statistics.]')
    table(1,'Canonical-molecule overlap in the recovered historical archive, before strict follow-up exclusions. The 411-row historical Q-HERO register differs from the cleaned 405-molecule classifier cohort.')
    para('The original five-fold representation benchmark compares MolFormer, ChemBERTa, Morgan and MACCS features. The four original author figures are retained below. These classify expert labels and do not measure quantitative MIC/MBC generalisation. The main-text MolFormer F1 value of 0.655 and any differently printed source-figure value require reconciliation against the archived fold outputs before submission.')
    for i,cap in [(1,'Original author-supplied representation-classification F1 comparison.'),(2,'Original author-supplied representation-classification accuracy comparison.'),(3,'Original author-supplied fold-specific classification comparison.'),(4,'Original author-supplied contrastive cluster diagnostics.')]:
        legacy(i,i,cap+' Source: Supporting_Info.docx. Raster bytes and source protocol are preserved.')
    heading(chapters[1])
    para('Frozen MolFormer supplies 768-dimensional molecular features. The reference external encoder has widths 768–512–384–256 and 691,584 trainable parameters; it updates its own weights without changing MolFormer. Archived StandardScaler and Borderline SMOTE (strategy 0.8) belong to the historical training procedure. The contrastive projection head is removed before quantitative decoding. Partial-backbone follow-ups in S4 are separate models.')
    table(45,'Original v5 Table 1, preserved numerical cells. Historical single-holdout point estimates are separate from newly reconstructed fold variability. The source E. coli MIC cell printed R²=0.60 corresponds to recovered R²=0.5918; the strain-header typo ATCC 4300 is preserved as an original-table typo for ATCC 43300.')
    table(46,'Original v5 Table 2, preserved numerical cells. The full-corpus quantitative checkpoint is not recovered; author-reported values are retained without attaching uncertainty from another experiment. The available QAC-only encoder is a different model.')
    para('Text task codes use OpenAI text-embedding-3-small, with four fixed 1,536-dimensional float32 vectors. The October cache was obtained through OpenRouter on the local Mac. Task descriptions match the recovered May notebook exactly, but the historical vector cache is unavailable: regenerated vectors are not claimed to be byte-identical. Species and endpoint descriptions, rather than molecular structures or target concentrations, were sent to the embedding service.')
    provenance=json.loads((REPRO/'revision_v24/task_text_embedding_provenance.json').read_text())
    newtable('Exact text inputs for the four task vectors.','Task|Input description'.split('|'),[(a['id'],a['text']) for a in provenance['tasks']],'task_inputs')
    para('Fixed task vectors are reused across folds. Categorical species/endpoint and categorical task-ID coding provide controls. The matched compact main Figure 5 uses native categorical codes; text-code substitution controls share one source checkpoint.')
    table(39,'Task-code substitution controls with human compact seed 0. Scores are pooled exact-endpoint RMSE; only the task-code association changes. The four-task, one-seed design does not establish transfer to unseen descriptions.')
    heading(chapters[2])
    para('Row-wise validation reconstructs the author workflow on 108 worksheet records representing 105 full salts. Withheld task rows may have another measurement of the same molecule in training. Cation and scaffold holdouts ask a separate question and keep their molecular groups outside the corresponding target-training folds. Strict follow-ups exclude target cations from source supervision before representation training.')
    para('Uncertainty conventions are explicit: row/fold SD uses five folds and ddof=0; source-seed SD uses five complete runs and ddof=1; backbone-route SD uses three complete runs and ddof=1. These spreads are not 95% confidence intervals. Paired bootstrap intervals condition on fixed trained predictors, resampling paired source seeds and groups; no multiplicity adjustment or model refitting is performed.')
    table(40,'Five-fold row-CV reconstruction: mean ± fold SD (ddof=0). These are new computations, not recovered intervals for the original v5 holdout tables.')
    figure(5,'figureS5_row_cv','Row-CV endpoint R² from saved results for raw and human-guided features. Bars show SD over five folds (ddof=0); symbols denote the three fixed task-coding configurations. Rows may share molecules with training; the plot is separate from grouped generalisation.')
    table(35,'Reconstructed original-108 holdout endpoint metrics. Original notebook point outputs, checkpoint availability and the regenerated text cache are distinguished from strict grouped evaluation.')
    para('Matched compact encoders use the same 681 source molecules, 377 training and 304 validation molecules, five paired source seeds and 480 updates without SMOTE. Frozen MolFormer features feed the v5 external encoder architecture. Human Good/Bad contrastive supervision is compared with continuous-MIC regression, binary-MIC controls, shuffled labels and raw features. Identical target-decoder budgets and partitions are retained within the comparison; objective differences are part of the declared learning procedures.')
    table(41,'Complete compact-arm results: mean ± sample SD across source runs (ddof=1). Single-checkpoint references have no invented SD. Each regime and task code remains separate.')
    table(36,'Every compact-control and archived-representation configuration: seed-mean RMSE. Historical and matched representations remain labelled; no configuration is selected by OOD scores.')
    figure(6,'figureS6_compact_seed_variability','Matched compact categorical-task pooled RMSE. Bars show sample SD over five source runs; raw features are one fixed reference without an SD. Cation/scaffold target scores and the 67-exact-endpoint OOD score use distinct evaluation regimes.')
    table(37,'Complete paired compact-control ΔRMSE intervals. Negative values favour the first configuration. These pointwise conditional intervals retain the stated clustering unit and source-run count.')
    heading(chapters[3])
    para('The direct adaptation experiment uses three paired runs, fixed five-fold cation/scaffold partitions and one full-QAC training fit for OOD per run. A frozen head, LoRA and full fine-tuning start from pretrained MolFormer. Human direct and Human › CatBoost share human-guided partial-backbone source checkpoints; direct target adaptation and frozen-feature decoding then differ. These routes compare entire prediction procedures rather than isolating human-label meaning.')
    for n in original:
        if txt(n).startswith(('The direct extension uses three paired seeds','For source-initialised direct prediction')):insert(n)
    table(28,'Complete direct-target pooled results: mean ± sample SD over three seed-specific scores, rather than metrics of averaged predictions. All route-specific trainable-parameter counts are preserved.')
    table(29,'Complete direct-target endpoint scores. RMSE and MAE are mean ± sample SD of three runs; R² and Spearman are reported under the original table convention. All tails and failed extrapolations remain available.')
    heading(chapters[4])
    for prefix in ['All model comparisons use the original v14 target folds','The CatBoost control retains 300 iterations','TabPFN 9.1.0 runs','Chemprop 2.3.1 trains','Across the fixed models, 913 fits']:
        n=deepcopy(next(n for n in original if txt(n).startswith(prefix)))
        for t in n.iter(qn('w:t')):
            if t.text:t.text=t.text.replace('in S21 and the run manifests','in S10 and the run manifests')
        insert(n)
    para('The archived v5-feature TabFM/TabPFN/AutoGluon extension below is a separate set of decoder fits from the earlier v14 source-matched extension described above. Their prediction files and checkpoint provenance are listed in S10. Different train-only PCA treatments, source data and optimisation budgets limit interpretation as matched architecture comparisons.')
    table(38,'Archived-v5-feature modern decoder endpoint results. Each method fits separate endpoint predictors; train-only PCA32 is used by the modern models. One archived source checkpoint is used, without source-seed uncertainty.')
    table(42,'Complete grouped fold variability for archived-feature and modern-decoder procedures. Mean ± fold SD uses five folds and ddof=0; fold means differ from pooled OOF metrics.')
    table(23,'Earlier fixed-model extension including Chemprop and all graph/tabular reference pipelines. Pooled scores use their declared one-hot v14 features and differ from the v5-feature modern extension above. Complete endpoint-level scores accompany this SI as fixed_model_endpoint_metrics.csv.')
    figure(7,'figureS7_modern_decoders','Pooled point RMSE for modern decoders using raw and archived human-guided features. Points are saved-fit scores, not means over source seeds. Endpoint details and grouped fold variability are in the adjacent tables. PCA and model budgets differ between procedures.')
    heading(chapters[5])
    para('Q-HERO is a separate classification test, not the original QAC MIC/MBC regression task. The cleaned cohort contains 405 molecules, 360 active at S. aureus MIC ≤8 µM and 45 inactive. The fixed random split contains 324 training and 81 test molecules, with nine inactive test molecules. Five scaffold folds cover 29 scaffolds. The 681-molecule source panel excludes target salts and cations.')
    para('Human, quantitative and shuffled-human features use matched partial-MolFormer adaptation. Independent CatBoost classifiers use 800 iterations, depth 6 and learning rate 0.05, with five paired source/decoder runs. Raw features and the author-style 35-descriptor RF are fixed seed-0 fits on the same cleaned targets and partitions. This is a common-cohort refit, not a replication victory over the published 421-row random test.')
    table(47,'Q-HERO405 classification. Mean ± sample SD over five paired source/decoder runs; fixed RF and raw references have one fit. Random and scaffold evaluations remain distinct. The partial-backbone features differ from the compact encoder in main Figure 5.')
    table(48,'Paired Q-HERO scaffold contrasts: 2,000 paired seed/scaffold bootstrap draws over fixed OOF predictions and 29 scaffolds. These unadjusted conditional intervals do not include full training-set resampling.')
    para('Human minus RF AUROC on the random test is +0.1052, conditional 95% interval [−0.0664,+0.2969]. Human minus quantitative AUROC on scaffold holdout is −0.0401 [−0.0876,+0.0269]. The random-test advantage and superiority to quantitative supervision are unresolved. Source: Ghaemi et al., JCIM 2026, DOI 10.1021/acs.jcim.6c00390; Q-HERO repository commit 52ab433a4abc626e164cf72d1a39f02eda260b52.')
    figure(8,'figureS8_qhero_average_precision','Q-HERO average precision from saved run-level summaries. Bars are sample SD across five paired runs; fixed references have no SD. Dashed lines mark positive-class prevalence (72/81 random test, 360/405 scaffold OOF). High precision–recall values are interpreted relative to this high prevalence.')
    heading(chapters[6])
    para('The reference register contains all 105 full salts, retaining original worksheet-row identifiers; the legacy 100-molecule use is a historical subset/protocol, not a substitute for the full register. The 17 newly synthesised compounds span kojic-acid, tetrahydropyridine, dihydropyran and glycoluril families. Frozen OOD predictors train quantitative decoders on the reference cohort only. OOD activity labels do not select checkpoints or tune those predictors.')
    table(19,'All 105 original full-salt identities and original worksheet-row identifiers. Exact structures, counterions and grouped identifiers accompany this SI as QAC105.csv and original_QAC105_registry.csv.')
    table(20,'All 17 OOD compounds and supplied MIC/MBC values in mg/L. IT505 E. coli MBC >500 mg/L remains a bound. Exact full-salt structures and family/source codes accompany this SI as OOD17.csv.')
    table(49,'OOD route scores on 67 exact endpoints. Repeated results are mean ± sample SD over the stated runs. Historical text-coded, matched compact categorical and backbone-route protocols are separate blocks.')
    figure(9,'figureS9_ood_endpoint_parity','Measured versus predicted OOD endpoints for source-matched compact human and quantitative encoders. Display predictions average five source-run predictions per compound, while reported tables average run-specific scores. There are 17 points per endpoint except E. coli MBC (16 exact values); the >500 mg/L bound is retained separately. Dashed lines show identity; no regression line or new score is fitted.')
    para('Exact-endpoint RMSE excludes the one right-censored observation. Its minimum absolute residual is max(log₂(500) − prediction, 0). The four-family bootstrap is a coarse sensitivity analysis with only four independent structural clusters; cation-clustered OOD intervals use 17 cations and answer a different resampling question. Categorical/text routes and compact/partial architectures must not be silently pooled.')
    table(22,'Right-censored endpoint minimum-error sensitivity under its original stated protocol. The lower-bound contribution does not turn the >500 mg/L value into an exact target.')
    table(33,'Per-run human-guided censored-endpoint sensitivity from independently replayed predictions. The final row averages run-specific RMSE values rather than predictions.')
    heading(chapters[7])
    para('Recovered geometry gives linear CKA 0.933243 on the reference cohort and 0.945559 on OOD compounds. Five-fold probes give R² 0.890919 ±0.036773 from MolFormer to human features and 0.844077 ±0.060385 in reverse (fold SD). These measure shared geometry and linear recoverability. They do not estimate independent biological and structural components.')
    table(43,'Recovered five-fold linear representation-probe results. These are coordinate-reconstruction scores, not MIC/MBC prediction uncertainty. Saved notebook outputs are the provenance source.')
    para('Saved May notebook output gives summed mean absolute SHAP values on the 67 exact OOD endpoints of 2.9301 for MolFormer features, 0.6359 for human features and 0.7605 for the task identifier. The human/raw block ratio is approximately 0.217. Correlated blocks and unequal dimensions preclude interpreting these sums as fractions of biological variance. Sources: analysis/cka_probing.csv and the saved output cells 4–5 of 2026-05-25_causal_final.ipynb.')
    figure(10,'figureS10_geometry_and_attribution','Archived representation geometry, five-fold linear probes and decoder SHAP block totals, redrawn from saved numeric outputs. Probe bars denote fold SD. CKA and SHAP have no invented uncertainty. These descriptive measures do not establish a biological mechanism or an additive causal decomposition.')
    para('Label permutation retains the same source molecules, partitions, class counts or continuous-value distribution and budget while disrupting assignment. Weight rewinds restore specified parameters while retaining the experiment-specific buffers. The compact weight-only reset retains BatchNorm state; partial rewinds are not the pure raw feature baseline. These interventions test dependence of prediction on the procedure, rather than the biological causal effect of a molecular fragment.')
    table(50,'Complete scaffold-clustered label and weight intervention contrasts plotted in Figure S11. Compact intervals use 10,000 paired seed/group draws; partial-backbone intervals use 5,000. OOD uses four structural families; fits remain fixed.')
    figure(11,'figureS11_figure9_interpretation_controls_futura','Label-permutation and weight-rewind ΔRMSE under scaffold-clustered conditional intervals. Cation/scaffold evaluation contains 29 scaffold clusters and OOD four families. Negative human-minus-shuffled values favour meaningful assignment; positive reset-minus-intact values favour retained updates. Architectures and decoders differ between panels; intervals are exploratory and unadjusted.')
    contrasts=read(REPRO/'revision_v29/inserted_figure_contrasts.csv')
    newtable('Numerical support for main Figure 9 and SI Figure S12. Cation holdout clusters 103 cations, scaffold holdout 29 scaffolds, OOD 17 cations; these intervals differ from the four-family sensitivity in Figure S11.', ['Architecture / contrast','Regime / cluster','Seeds / groups / draws','ΔRMSE','Conditional 95% CI'],[(f"{r.panel} / {r.comparison}",f"{r.schema} / {r.grouping}",f"{r.seeds} / {r.groups} / {r.draws}",f'{r.delta:+.4f}',f'[{r.low:+.4f}, {r.high:+.4f}]') for r in contrasts.itertuples()],'main_figure9')
    figure(12,'figureS12_figure10_supervision_contrasts_futura','Source-supervision contrasts, identical to main Figure 9. Points and conditional paired bootstrap intervals come from the adjacent numerical table; different grouping units produce different interval widths from Figure S11. An interval spanning zero does not establish equivalence. No training or metrics were recomputed for the redraw.')
    heading(chapters[8])
    para('Chemical characterisation and microbiological methods below are preserved from the author-provided v5 material. Their citation numbers follow the main article bibliography. Full NMR, HRMS and FT-IR source spectra, synthetic optimisation records and supplementary scheme source files remain for coauthor completion; calculated spectra or inferred yields are not substituted.')
    chemical=newtable('THP multicomponent-reaction optimisation — reserved for the original experimental record cited in main Section 2.3.2. The optimisation table was absent from the computational SI; no yield or condition is inferred.', ['Required author material','Status'], [('Original entries, including entries 3 and 7','[COAUTHORS: insert the original optimisation table and experimental conditions]')],'chemistry_optimisation')
    para('Scheme S1. [COAUTHORS: insert the original competitive THP/4H-pyran cyclisation scheme cited in Section 2.3.2.]','Caption')
    para('Scheme S2. [COAUTHORS: insert the original THP epimerisation scheme cited in Section 2.3.2.]','Caption')
    mainbody=list(Document(MAIN)._element.body)
    start=next(i for i,n in enumerate(mainbody) if txt(n)=='4.1 Chemistry')
    end=next(i for i,n in enumerate(mainbody[start:],start) if txt(n).startswith('5. CRediT'))
    for n in mainbody[start:end]:
        c=deepcopy(n)
        for t in c.xpath('.//w:t'):
            if t.text and re.match(r'^4\.[12](?:\.| )',t.text):t.text=re.sub(r'^4\.', 'S9.',t.text)
        insert(c)
    heading(chapters[9])
    para('All new SI graphics are generated from preserved outputs; no model is retrained and no historical metric is replaced. Historical notebook cells establish provenance separately from exact independent replay. Re-encoding MolFormer under a different batch layout can perturb features around 10⁻⁶ and change some CatBoost decisions. The archived layout reproduces the checked arrays and predictions; altered-layout results remain labelled sensitivity analyses.')
    table(26,'Independent reproduction outcomes for the original v14 workflows. Archived-layout primary results and altered-layout sensitivities remain distinct; incomplete frozen-feature MLP cross-environment branches are retained as limitations.')
    table(34,'Original v5 hypotheses and corresponding follow-ups. Point-score continuity, source matching, annotation provenance and unresolved limitations remain explicit.')
    table(44,'Relationship of added computations to the author workflow. Representation, target learner and changes of protocol are preserved.')
    para('Machine-readable companion data provide exact task inputs, the 105 full salts, the 17 OOD compounds, run/fold summary scores, bootstrap contrasts and plot values. SHA256 hashes and source-to-current table mappings are in revision_manifest.json and SI_REFERENCE_MAP_RU.md. Complete raw predictions remain in the referenced reproducibility directories; this package does not claim to contain every trained model checkpoint.')
    para('Model and dataset references','Heading 2')
    for n in original:
        s=txt(n)
        if re.match(r'(4\.|6\.|7\.|8\.|9\.|10\.|11\.|12\.) ',s) and any(x in s for x in ['Ross, J.','Hu, E.','Heid, E.','Hollmann, N.','Google Research.','Erickson, N.','Schölkopf, B.','Ghaemi, S.']):
            para(re.sub(r'^\d+\.\s*','',s))
    para('Bibliography for retained chemical records','Heading 2')
    refs=next(i for i,n in enumerate(mainbody) if txt(n)=='References')
    for n in mainbody[refs+1:]:
        if txt(n).strip():para(txt(n))
    heading(chapters[10])
    legacy(33,13,'Original v5 zero/few-shot OOD raster. Its few-shot arm uses OOD labels for adaptation and is separate from untouched frozen OOD validation. Repeated disjoint few-shot uncertainty is not established by the supplied archive; source image bytes are preserved.')
    legacy(34,14,'Original v5 information-flow raster. This is a historical conceptual illustration, not an estimated biological/structural decomposition. Geometry, SHAP and computational interventions do not identify that decomposition; current interpretation and controls are given in S8.')
    para('The historical residual-based causal-forest experiment is retained in the separate full computational archive (SI_v27_full_archive.docx). Assigning treatment to model residuals does not isolate source chemistry, source information access, loss function or checkpoint provenance. No prospective equivalence margin was supplied; a non-significant difference does not establish equivalence. These archived analyses are not used as biological causal evidence.')
    para('Preserved materials outside this focused SI','Heading 2')
    para('SI_v27_full_archive.docx retains every preceding supplementary table, figure and earlier protocol without alteration. Its numbering is historical and is not used by the aligned revision-30 article. The original Supporting_Info.docx source is retained separately. The current SI does not relabel earlier 411-molecule Q-HERO regression or micromolar protocols as the 405-molecule classification comparison.')
    return chemical

def finish_document():
    for p in doc.paragraphs:
        if p.text.startswith('[COAUTHORS:') or '[COAUTHORS:' in p.text:
            for r in p.runs:r.font.highlight_color=7
    for table in doc.tables:
        table.autofit=True
        for ri,row in enumerate(table.rows):
            if ri==0:
                pr=row._tr.get_or_add_trPr();rep=OxmlElement('w:tblHeader');pr.append(rep)
            for cell in row.cells:
                for p in cell.paragraphs:
                    p.paragraph_format.space_after=Pt(3);p.paragraph_format.line_spacing=1
                    for r in p.runs:r.font.name='Futura';r.font.size=Pt(8);r.font.color.rgb=RGBColor.from_string('1B1C1F')
                    if '[COAUTHORS:' in p.text:
                        for r in p.runs:r.font.highlight_color=7
                if ri==0:
                    pr=cell._tc.get_or_add_tcPr();sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'F1F9F6');pr.append(sh)
    for r in doc._element.xpath('.//w:r'):
        pr=r.find(qn('w:rPr'))
        if pr is None:pr=OxmlElement('w:rPr');r.insert(0,pr)
        f=pr.find(qn('w:rFonts'))
        if f is None:f=OxmlElement('w:rFonts');pr.insert(0,f)
        for name in ['ascii','hAnsi','eastAsia','cs']:f.set(qn('w:'+name),'Futura')
        for a in list(f.attrib):
            if a.endswith('Theme'):del f.attrib[a]
    for f in doc._element.iter(qn('w:rFonts')):
        for name in ['ascii','hAnsi','eastAsia','cs']:f.set(qn('w:'+name),'Futura')
        for a in list(f.attrib):
            if a.endswith('Theme'):del f.attrib[a]
    # Old imported SI images are scaled to the available width without changing bytes.
    for inline in doc.inline_shapes:
        if inline.width>Inches(6.9):
            h=inline.height;w=inline.width;inline.width=Inches(6.9);inline.height=int(h*inline.width/w)
    doc.core_properties.title='Supporting Information — manuscript-aligned revision 30'
    doc.core_properties.subject='Expert supervision, quantitative controls, QAC105, Q-HERO405 and OOD17'
    doc.save(ROOT/'Supplementary_Information_v30.docx')

def align_main(chemical):
    ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    with ZipFile(MAIN) as z:files={n:z.read(n) for n in z.namelist()}
    raw=files['word/document.xml'];tree=E.fromstring(raw);body=tree.find('w:body',ns);changes=[]
    spans=list(re.finditer(rb'<w:p(?:\s[^>]*)?>[\s\S]*?</w:p>',raw))
    patches=[]
    for i,n in enumerate(body):
        before=txt(n)
        if not before or n.tag!=qn('w:p'):continue
        after=before
        after=after.replace('Figure SI 1-2','Figures S1–S2')
        after=after.replace('SI Section S34','SI Section S2').replace('SI S34','SI Section S2')
        # References are confined to table/figure contexts; chemistry Table S1 has its own mapping.
        for old,new in [(34,14),(33,13),(35,11)]:
            after=after.replace(f'Figure S{old}',f'Figure __FIGREF{new}__')
        if 'Table' in after:
            def repl(m):
                old=int(m[1]);return 'S'+str(chemical if old==1 and 'MCR conditions' in before else TABLE_MAP.get(old,old))
            after=re.sub(r'\bS(\d+)\b',repl,after)
        after=re.sub(r'Figure __FIGREF(\d+)__',r'Figure S\1',after)
        # Nonadjacent source table ranges must be expressed as separate current references.
        if 'Tables S7–S9' in after:after=after.replace('Tables S7–S9','Tables S7 and S9')
        if before!=after:
            # Match the raw paragraph by its own XML location; retain every original media/OLE part.
            candidates=[]
            for m in spans:
                try:
                    wrap=E.fromstring(b'<root '+b' '.join(b'xmlns:'+k.encode()+b'="'+v.encode()+b'"' for k,v in tree.nsmap.items() if k)+b'>'+m.group()+b'</root>')
                    if ''.join(wrap.xpath('.//w:t/text()',namespaces=ns))==before:candidates.append(m)
                except E.XMLSyntaxError:pass
            assert len(candidates)==1,(i,len(candidates),before[:80])
            m=candidates[0];chunk=m.group();texts=list(re.finditer(rb'<w:t(?:\s[^>]*)?>[\s\S]*?</w:t>',chunk))
            # Replace only changed text tokens, keeping all paragraph/run structures.
            # SequenceMatcher maps edited references into the original run boundaries.
            import difflib
            tokens=[E.fromstring(b'<root xmlns:w="'+ns['w'].encode()+b'">'+x.group()+b'</root>')[0].text or '' for x in texts]
            offsets=np.cumsum([0]+[len(x) for x in tokens]);newtokens=tokens[:]
            edits=[o for o in difflib.SequenceMatcher(None,before,after,autojunk=False).get_opcodes() if o[0]!='equal']
            for _,a,b,c,d in reversed(edits):
                first=max(0,min(len(tokens)-1,int(np.searchsorted(offsets,a,side='right')-1)))
                last=max(first,min(len(tokens)-1,int(np.searchsorted(offsets,max(a,b-1),side='right')-1)))
                if first==last:newtokens[first]=newtokens[first][:a-offsets[first]]+after[c:d]+newtokens[first][b-offsets[first]:]
                else:
                    newtokens[first]=newtokens[first][:a-offsets[first]]+after[c:d]
                    for k in range(first+1,last):newtokens[k]=''
                    newtokens[last]=newtokens[last][b-offsets[last]:]
            from xml.sax.saxutils import escape
            for tm,value in reversed(list(zip(texts,newtokens))):
                tag=tm.group().split(b'>',1)[0]+b'>'
                chunk=chunk[:tm.start()]+tag+escape(value).encode()+b'</w:t>'+chunk[tm.end():]
            check=E.fromstring(b'<root xmlns:w="'+ns['w'].encode()+b'" '+b' '.join(b'xmlns:'+k.encode()+b'="'+v.encode()+b'"' for k,v in tree.nsmap.items() if k and k!='w')+b'>'+chunk+b'</root>')
            assert ''.join(check.xpath('.//w:t/text()',namespaces=ns))==after
            patches.append((m.start(),m.end(),chunk));changes.append({'body_index':i,'before':before,'after':after})
    for a,b,c in reversed(patches):raw=raw[:a]+c+raw[b:]
    E.fromstring(raw);files['word/document.xml']=raw
    with ZipFile(OUTMAIN,'w',ZIP_DEFLATED) as z:
        for name,value in files.items():z.writestr(name,value)
    return changes

def main():
    originals={str(p):sha(p) for p in [OLD,MAIN,COMA/'2026_07_09_Paper_2_edited-v5_NF_3.docx']}
    plots();chemical=build();finish_document();changes=align_main(chemical)
    shutil.copy2(OLD,ROOT/'SI_v27_full_archive.docx')
    shutil.copy2(REPRO/'revision_v17/sources/Supporting_Info_original.docx',ROOT/'Supporting_Info_original.docx')
    companions={'QAC105.csv':'v5_hypotheses_20261013/data/QAC105.csv','OOD17.csv':'v5_hypotheses_20261013/data/OOD17.csv','endpoint_registry.csv':'v5_hypotheses_20261013/data/endpoint_registry.csv','row_cv_summary.csv':'revision_v19/rowcv_results/summary.csv','compact_seed_summary.csv':'revision_v19/analysis/seed_summary.csv','compact_metrics.csv':'revision_v18/analysis/summary.csv','compact_contrasts.csv':'revision_v18/analysis/contrasts.csv','modern_metrics.csv':'revision_v18/analysis/modern_metrics.csv','backbone_route_scores.csv':'revision_v24/analysis/FT_route_RMSE_mean_sample_SD.csv','QHERO_metrics.csv':'qhero_author_comparison_20261014/results/summary.csv','QHERO_scaffold_contrasts.csv':'qhero_author_comparison_20261014/results/paired_scaffold_contrasts.csv','OOD_error_plot_values.csv':'revision_v26/OOD_violin_values.csv','interpretation_family_contrasts.csv':'revision_v26/interpretation_contrasts.csv','main_figure9_contrasts.csv':'revision_v29/inserted_figure_contrasts.csv','task_text_embedding_provenance.json':'revision_v24/task_text_embedding_provenance.json'}
    registry=next(REPRO.rglob('original_QAC105_registry.csv'),None)
    if registry:shutil.copy2(registry,DATA/registry.name)
    for dest,src in companions.items():
        p=REPRO/src;assert p.exists(),p;shutil.copy2(p,DATA/dest);INPUTS[str(p.relative_to(COMA))]=sha(p)
    additional={DATA/'fixed_model_endpoint_metrics.csv':REPRO/'server_models_20261012/analysis/all_model_metrics.csv',ROOT/'original_QAC105_structures_ACS1996.pdf':REPRO/'revision_v14/figures/original_QAC105_structures.pdf',ROOT/'OOD17_structures_ACS1996.pdf':REPRO/'revision_v14/figures/OOD17_structures.pdf'}
    for dest,src in additional.items():
        shutil.copy2(src,dest);INPUTS[str(src.relative_to(COMA))]=sha(src)
    for p,h in originals.items():assert sha(p)==h
    manifest={'font':'Futura Medium','theme':'reproducibility/revision_v27/theme_v27.py','SI':str(ROOT/'Supplementary_Information_v30.docx'),'aligned_main':str(OUTMAIN),'source_hashes':originals,'inputs_sha256':INPUTS,'table_map':TABLE_MAP,'tables':COPIED_TABLES,'figures':FIGURES,'archival_raster_figures':[1,2,3,4,13,14],'figure_map':{'33':13,'34':14,'35':11},'main_changes':changes,'chemical_table':chemical,'main_figure9_table':next(r['number'] for r in COPIED_TABLES if r['old']=='main_figure9'),'model_training_performed':False,'copied_numeric_cells_preserved':True,'pending_author_material':['annotation provenance and original classification F1 reconciliation','THP optimisation table','Scheme S1 and Scheme S2','source NMR/HRMS/FT-IR spectra']}
    (ROOT/'revision_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    lines=['# Ссылки статьи на обновлённый SI','',f'Статья: `{OUTMAIN.name}`. Основной текст и рисунки сохранены; изменены только ссылки на SI.','',f'Текст и новые графики: Futura Medium. Шесть исходных растровых рисунков сохраняют оригинальное содержимое и шрифт внутри изображения.','', '| Было в SI v27 | Теперь | Содержание |','|---|---|---|']
    lines += [f"| Table S{r['old']} | Table S{r['number']} | {r['caption'].split('. ')[0]} |" for r in COPIED_TABLES if isinstance(r['old'],int)]
    lines += ['', 'Figure S33 → S13 (исходный few-shot); S34 → S14 (исходная схема); S35 → S11 (контроли). Сведения text-embedding-3-small: раздел S2.', '',f'Ссылка химической части на старую Table S1 исправлена на Table S{chemical}: пока это явно обозначенное место для исходной таблицы оптимизации. Scheme S1–S2 также оставлены для соавторов.','', 'Все прежние вычисления сохранены отдельно в SI_v27_full_archive.docx. Его номера не используются в обновлённой статье.']
    (ROOT/'SI_REFERENCE_MAP_RU.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({'SI':manifest['SI'],'main':str(OUTMAIN),'tables':len(COPIED_TABLES),'new_current_figures':len(FIGURES),'main_reference_paragraphs_changed':len(changes),'pending_author_material':manifest['pending_author_material']},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
